Steps to Run Application

1. Run TimesheetDB Script.
2. Download Project from https://github.com/saineshwar/WebTimeSheetManagement
3. Make Changes in Connection Strings { "Data Source" , user id ,password }
4. Do Fork and Star on Github.
5. Run Application.

Finally Read to Use.

Thank you.
